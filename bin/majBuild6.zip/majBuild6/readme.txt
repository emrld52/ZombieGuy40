major build 6 :

features

window opening - YES
triangle rendering - YES
quad rendering - YES
texture rendering - YES
converting from world space to clip space - YES
sprites of different aspect ratios and resolutions - NO
alpha blending - YES
basic platformer controls with psuedo collision - YES
WIP ai with psuedo collision - YES
UI basics - YES
animation system - NO
tilemap and real collision system - NO
projectiles - NO
multiple enemy ai types - NO
main menu - NO
sound - NO

minor features

screen shake

press e to spawn zombies