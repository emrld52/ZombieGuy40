major build 7 :

features :

window opening - YES
triangle rendering - YES
quad rendering - YES
texture rendering - YES
converting from world space to clip space - YES
sprites of different aspect ratios and resolutions - YES // new!!!
alpha blending - YES
basic platformer controls with psuedo collision - YES
WIP ai with psuedo collision - YES
UI basics - YES
art - MOSTLY
animation system - YES
tilemap and real collision system - YES
projectiles - NO
upgrades that fall from sky - NO
multiple enemy ai types - NO
scaling enemies overtime/actual game loop - NO
main menu - NO
sound - NO

maybe features :

simulate virtual resolution at 640x480 and scale up via nearest neighbour for retro style pixel snapping. have cool borders on sides in 16:9
hard mode in main menu

minor features complete :

screen shake

debug :

press e to spawn zombies