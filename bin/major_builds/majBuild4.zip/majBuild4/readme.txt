WORKING SPRITE RENDERER. MAJOR BUILD 4 (initial test, basic character controller with hardcoded collision 
delta time, global variables and state, input system)

open cmd

run zom.exe in any folder that has a folder called "assets" inside of it, make an "img" folder inside of "assets"

inside of "assets/img/" make sure theres an image called "bob.png"

bob.png has to have an alpha channel (transparency)

as long as bob.png is in assets/img/ this should work