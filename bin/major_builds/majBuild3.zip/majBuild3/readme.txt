WORKING SPRITE RENDERER. MAJOR BUILD 3 (initial test, texture loading currently 
one at a time, draw calls, draw multiple sprites in different positions)

open cmd

run zom.exe in any folder that has a folder called "assets" inside of it, make an "img" folder inside of "assets"

inside of "assets/img/" make sure theres an image called "bob.png"

bob.png has to have an alpha channel (transparency)

as long as bob.png is in assets/img/ this should work